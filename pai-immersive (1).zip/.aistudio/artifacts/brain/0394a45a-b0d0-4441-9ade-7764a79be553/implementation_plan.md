# PAI IMMERSIVE LEARNING

Aplikasi Android pembelajaran interaktif untuk mata kuliah **Strategi Pembelajaran Pendidikan Agama Islam (PAI)** di perguruan tinggi, yang memadukan ruang kelas virtual 3D interaktif berbasis A-Frame/WebXR, simulasi pedagogis kontekstual Nusantara, Laboratorium Generative AI berbasis Gemini, serta pelacakan progres belajar dan notifikasi real-time melalui cloud.

---

## User Review & Critical Decisions

> [!IMPORTANT] Seluruh keputusan arsitektur inti telah dikonfirmasi pada tahap klarifikasi dan akan diterapkan langsung dalam implementasi.

- **Antarmuka & Ruang Kelas Virtual 3D**: Antarmuka utama dibangun secara native dengan **Jetpack Compose (Material Design 3)**, sementara ruang kelas virtual 3D interaktif menggunakan **A-Frame / WebXR** yang tersemat di dalam Android `WebView` dengan jembatan dua arah (sentuh, geser kamera, pemilihan objek 3D, serta mode VR dengan fallback 3D standar otomatis).
- **Penyimpanan Progres & Autentikasi**: Menggunakan **Firebase Firestore** (database bernama khusus proyek) yang diproteksi dengan **Google Sign-In** melalui Jetpack Credential Manager, sehingga skor kuis, pilihan strategi, hasil analisis kasus, dan refleksi tersinkronisasi aman per akun mahasiswa secara real-time.
- **Integrasi Gemini AI**: Menggunakan **Firebase AI Logic** (`Firebase.ai` dengan App Check) tanpa menyimpan API key di sisi klien, dilengkapi indikator loading, propagasi error yang jelas, serta tombol/mode **Simulasi Lokal** sebagai fallback terpadu saat offline atau koneksi gagal.
- **Alur Navigasi 10 Tahap**: Menggunakan pola **Terpandu Berurutan dengan Akses Bebas Meninjau**—mahasiswa membuka tahap berikutnya secara bertahap setelah menyelesaikan aktivitas aktif, dan dapat meninjau ulang tahap yang sudah terbuka kapan saja melalui peta progres.

---

## 1. Overview & Core Concept

- **Apa yang Dibangun**: Laboratorium virtual Strategi Pembelajaran PAI berbahasa Indonesia penuh yang membimbing mahasiswa dari pemahaman tujuan mata kuliah, eksplorasi ruang kelas madrasah/pesantren 3D, tiga simulasi interaksi pedagogis (karakteristik peserta didik, kearifan lokal, dan pemilihan strategi), eksperimen di Laboratorium GenAI, evaluasi kuis & refleksi, hingga laporan hasil pembelajaran komprehensif.
- **Target Pengguna**: Mahasiswa program studi Pendidikan Agama Islam (PAI) tingkat perguruan tinggi serta dosen pengampu yang mempresentasikan atau menguji skenario strategi pembelajaran.
- **Nilai Utama**: Mengubah teori strategi pembelajaran PAI yang abstrak menjadi pengalaman spasial dan analitis yang dapat diklik, dieksplorasi secara 3D, diuji dengan AI Tutor akademis, serta tercatat progresnya secara real-time.

---

## 2. User Experience & Visual Design

### Alur Pembelajaran 10 Tahap

1. **Beranda**: Menampilkan logo dan identitas **PAI IMMERSIVE LEARNING**, ringkasan deskripsi laboratorium virtual, ringkasan tujuan pembelajaran, tombol **MULAI PEMBELAJARAN**, tombol **PETUNJUK PENGGUNAAN** (modal panduan interaktif), serta status akun Google & progres terkini.
2. **Tujuan Pembelajaran**: Menyajikan Capaian Pembelajaran Mata Kuliah (CPMK), indikator ketercapaian, dan peta alur 10 tahap yang interaktif.
3. **Masuk Ruang Kelas Virtual 3D**: Memuat ruang kelas madrasah/pesantren 3D berbasis A-Frame (arsitektur lengkung Islami sederhana, ornamen geometris halus, papan tulis interaktif, meja & kursi siswa, guru, mushaf Al-Qur'an, dan panel motif batik). Mahasiswa dapat menavigasi dengan sentuhan/geser serta menekan tombol **Masuk Mode VR** (jika didukung WebXR) atau bertahan di **Mode 3D Interaktif** sebagai fallback.
4. **Eksplorasi Objek Pembelajaran**: Mahasiswa memilih dan memeriksa objek 3D di dalam kelas (Papan Tulis Interaktif, Mushaf Al-Qur'an, Kitab Kuning/Pesantren, Panel Batik & Kearifan Lokal, dan Kelompok Siswa) untuk membuka catatan pedagogis tiap objek dan menandai eksplorasi selesai.
5. **Interaksi 1 — Analisis Karakteristik Peserta Didik**: Simulasi profil 4 tipe siswa di kelas (Visual, Auditori, Kinestetik, dan kemampuan akademik beragam). Mahasiswa menganalisis kebutuhan belajar masing-masing dan mencocokkan pendekatan diferensiasi yang sesuai dengan umpan balik langsung.
6. **Interaksi 2 — Integrasi Kearifan Lokal**: Skenario kelas PAI yang memadukan **Tradisi Pesantren**, **Budaya Gotong Royong**, **Batik sebagai Konteks Pembelajaran**, dan **Tradisi Masyarakat Lokal**. Mahasiswa memilih rancangan integrasi terbaik untuk tiap konteks budaya dan menerima penjelasan nilai pedagogisnya.
7. **Interaksi 3 — Pemilihan Strategi Pembelajaran**: Menyajikan kasus permasalahan kelas PAI nyata dan pilihan 6 strategi (*Problem Based Learning*, *Project Based Learning*, *Cooperative Learning*, *Contextual Teaching and Learning*, *Demonstrasi*, dan *Diskusi Interaktif*). Setiap pilihan memicu umpan balik pedagogis mendalam beserta alasan kecocokan atau ketidakcocokannya.
8. **Laboratorium Generative AI**: Studio AI akademis dengan 4 aksi utama—**GENERATE CASE STUDY**, **GENERATE QUIZ**, **ANALISIS STRATEGI**, dan **TANYA AI TUTOR**—yang menghasilkan skenario pembelajaran, soal adaptif berdasarkan jawaban mahasiswa, rekomendasi strategi, penjelasan, serta rancangan kegiatan pembelajaran PAI tanpa mengarang dalil atau sumber agama. Dilengkapi indikator loading, pesan kesalahan informatif, serta fallback simulasi lokal otomatis/manual.
9. **Evaluasi Pembelajaran & Refleksi**: Kuis pilihan ganda interaktif dengan umpan balik otomatis per butir soal, pembahasan jawaban, kalkulasi skor akhir, rekomendasi materi untuk dipelajari kembali, serta formulir refleksi pembelajaran mahasiswa.
10. **Hasil Pembelajaran**: Dasbor rangkuman akhir berisi skor mahasiswa, daftar strategi yang berhasil dipilih, ringkasan hasil analisis kasus, catatan refleksi, dan rekomendasi pengembangan kompetensi—semuanya tersinkronisasi ke cloud.

### Identitas Visual & Tema

- **Arah Estetika**: *Academic Heritage Madrasah*—nuansa akademis perguruan tinggi Islam Indonesia yang elegan, bersih, dan modern dengan aksen arsitektural madrasah yang tenang.
- **Palet Warna & Token**:
  - Warna Utama (*Primary*): **Emerald Green** (`#0D5C43` utama, `#073D2C` emerald gelap untuk header/kontras tinggi).
  - Latar & Permukaan (*Background / Surface*): **Ivory White** (`#FAF7F0` latar utama, `#FFFFFF` kartu utama, `#F2ECE0` permukaan sekunder hangat).
  - Warna Aksen (*Accent / Secondary*): **Warm Gold** (`#C6922C` emas akademis, `#F6E9C9` container emas lembut untuk lencana pencapaian dan penanda progres aktif).
  - Teks & Netral: Hijau-hitam arang (`#17231F`) untuk keterbacaan tinggi di atas ivory, serta warna semantik untuk status berhasil, peringatan, dan error.
- **Tipografi & Hierarki**: Memasang font lokal **Playfair Display** untuk judul akademis/banner utama dan **Plus Jakarta Sans** untuk teks antarmuka, soal evaluasi, dan percakapan AI Tutor agar nyaman dibaca pada layar ponsel maupun tablet.
- **Tata Letak Adaptif & Umpan Balik Interaktif**:
  - Mendukung layar ponsel (*Compact*) dan tablet/landscape (*Medium/Expanded*) dengan lebar konten terstruktur, target sentuh minimal 48dp, serta penanganan aman area notch dan navigation bar (*edge-to-edge*).
  - **Sistem Notifikasi Progres Real-Time**: Bilah status/notifikasi real-time di bagian atas dan pusat notifikasi dalam aplikasi yang langsung memperbarui dan mengumumkan progres pencapaian mahasiswa setiap kali tahap diselesaikan atau disinkronkan dengan Firestore (disertai notifikasi sistem Android opsional untuk pencapaian utama).

---

## 3. Key Product Decisions & Trade-Offs

- **Jetpack Compose + Embedded A-Frame WebXR (Bukan Full WebView Wrapper)**
  - *Pendekatan Dipilih*: Antarmuka utama, navigasi 10 tahap, kuis, dan Laboratorium GenAI dibangun secara native di Jetpack Compose, sementara ruang kelas 3D A-Frame berjalan di `WebView` khusus dengan komunikasi `@JavascriptInterface`.
  - *Alasan*: Memberikan performa UI mobile yang responsif, integrasi aman dengan Firebase Auth (Credential Manager) dan Firebase AI Logic SDK native, sambil tetap mempertahankan mesin 3D A-Frame/WebXR yang interaktif dan dapat diklik langsung.
  - *Alternatif yang Dipertimbangkan*: Membungkus seluruh aplikasi React di dalam WebView, yang akan mempersulit integrasi Google Sign-In Credential Manager dan App Check native.

- **Firebase AI Logic dengan Fallback Simulasi Lokal**
  - *Pendekatan Dipilih*: Semua fitur GenAI memanggil model `gemini-3.8-flash` melalui `Firebase.ai` (diamankan oleh App Check, tanpa API key di frontend). Jika perangkat offline, batas kuota tercapai, atau pengguna mengaktifkan mode offline, aplikasi menyediakan konten simulasi lokal pedagogis PAI yang terkurasi.
  - *Alasan*: Menjamin keamanan kredensial penuh di sisi klien, latensi rendah dengan streaming, dan keandalan saat presentasi/uji coba tanpa koneksi stabil.
  - *Alternatif yang Dipertimbangkan*: Panggilan REST langsung dengan API key di frontend, yang berisiko kebocoran kunci.

- **Firebase Firestore + Google Sign-In (Credential Manager)**
  - *Pendekatan Dipilih*: Data progres 10 tahap, skor evaluasi, analisis kasus, riwayat GenAI, dan refleksi disimpan di koleksi per pengguna pada Firestore yang hanya dapat diakses pemilik akun Google terautentikasi.
  - *Alasan*: Menjaga durabilitas data lintas sesi/perangkat, memungkinkan pembaruan progres real-time melalui snapshot listener, dan mematuhi isolasi keamanan multi-pengguna.
  - *Alternatif yang Dipertimbangkan*: Penyimpanan lokal saja (Room), yang tidak mendukung sinkronisasi cloud maupun pemulihan progres antar perangkat.

---

## 4. Technical Architecture & Data Strategy

### Diagram Arsitektur & Hirarki Komponen

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         PAI IMMERSIVE LEARNING                            │
│                        (MainActivity + App Check)                         │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │
                       ┌──────────────▼──────────────┐
                       │    Gerbang Autentikasi      │
                       │  (Credential Manager Google │
                       │   Sign-In + Firebase Auth)  │
                       └──────────────┬──────────────┘
                                      │ UID Terverifikasi
┌─────────────────────────────────────▼─────────────────────────────────────┐
│                     Alur Pembelajaran Terpandu (10 Tahap)                 │
│  ┌──────────────┐  ┌─────────────────────────┐  ┌──────────────────────┐  │
│  │ Beranda &    │  │ Virtual Classroom 3D    │  │ 3 Aktivitas Interaktif│ │
│  │ Tujuan       │  │ (WebView A-Frame/WebXR  │  │ - Karakteristik Siswa│  │
│  │ Pembelajaran │  │  + JS Bridge Interaksi) │  │ - Kearifan Lokal     │  │
│  └──────────────┘  └─────────────────────────┘  │ - Strategi Belajar   │  │
│                                                  └──────────────────────┘  │
│  ┌──────────────────────────┐  ┌───────────────────────────────────────┐  │
│  │ Laboratorium GenAI       │  │ Evaluasi Kuis, Refleksi & Hasil Akhir │  │
│  │ (Case, Quiz, Analisis,   │  │ (Skor, Pembahasan, Rekomendasi,       │  │
│  │  AI Tutor + Simulasi)    │  │  Notifikasi Progres Real-Time)        │  │
│  └─────────────┬────────────┘  └───────────────────┬───────────────────┘  │
└────────────────┼───────────────────────────────────┼──────────────────────┘
                 │                                   │
   ┌─────────────▼─────────────┐       ┌─────────────▼─────────────┐
   │   AiLabRepository         │       │  LearningProgressRepo     │
   │ - Firebase.ai (Gemini)    │       │  - Firestore Named DB     │
   │ - Structured JSON Schema  │       │  - Snapshot Listeners     │
   │ - Local Simulation Engine │       │  - Real-Time Notif Feed   │
   └───────────────────────────┘       └───────────────────────────┘
```

### Model Data & Strategi Penyimpanan (Firestore)

Seluruh data tersimpan di database bernama proyek (`firestore_database_id`) di bawah ruang lingkup pengguna terautentikasi:

- **Profil & Ringkasan Progres Pengguna**: Menyimpan nama tampilan, email terisolasi kepemilikan, tahap tertinggi yang terbuka, daftar tahap selesai, objek 3D yang sudah dieksplorasi, skor kuis akhir, strategi yang berhasil dipilih, ringkasan analisis kasus, refleksi pembelajaran, serta timestamp server (`createdAt`, `updatedAt`).
- **Riwayat Aktivitas & Log GenAI**: Menyimpan sesi studi kasus, kuis adaptif, analisis strategi, dan catatan tutor yang dihasilkan selama pembelajaran.
- **Feed Notifikasi Progres Real-Time**: Subkoleksi/aliran event progres per pengguna yang dipantau melalui `snapshots()` sehingga bilah notifikasi dan lencana progres langsung diperbarui secara real-time saat mahasiswa menyelesaikan setiap tahap atau aktivitas.
- **Aturan Keamanan (`firestore.rules`)**: Memvalidasi autentikasi aktif, kepemilikan `request.auth.uid == userId`, integritas tipe & batas panjang string/angka, serta larangan akses lintas pengguna, diverifikasi melalui unit test emulator sebelum deployment aturan.

### Pemetaan Interaksi & State Utama

- **Bridge Virtual Classroom 3D**: Ketukan pada objek di scene A-Frame (Papan Tulis, Mushaf, Kitab Pesantren, Panel Batik, Kursi Siswa) mengirim pesan JSON melalui `@JavascriptInterface` ke ViewModel untuk membuka panel informasi objek dan mencatat kemajuan tahap eksplorasi ke Firestore.
- **Laboratorium GenAI**: State terkelola melalui `UiState` (*Idle*, *Loading*, *Streaming*, *Success*, *Error*) dengan timeout 60 detik. Fitur `GENERATE QUIZ` membaca performa jawaban mahasiswa sebelumnya untuk menyesuaikan tingkat kesulitan soal berikutnya secara adaptif. Prompt sistem menjaga bahasa akademis yang jelas dan melarang fabrikasi ayat Al-Qur'an, hadis, maupun referensi dalil palsu.
- **Evaluasi & Hasil Akhir**: Setiap jawaban kuis langsung memicu umpan balik dan pembaruan skor berjalan; setelah refleksi dikirim, aplikasi mengunci capaian modul dan menyusun rekomendasi pengembangan kompetensi pada layar Hasil Pembelajaran.

### Urutan Integrasi Backend & Verifikasi

1. Ekstraksi sidik jari sertifikat debug lokal, pengajuan persetujuan setup Firebase (`firestore` dan `ai_logic`), serta provisioning resource backend.
2. Pembuatan skema blueprint Firestore, aturan keamanan zero-trust, pengujian aturan pada emulator lokal, serta deployment aturan terverifikasi.
3. Konfigurasi `configureAppCheck(this, intent)` di `MainActivity` sebelum UI/ViewModel, implementasi gerbang Google Sign-In, aset A-Frame 3D lokal, 10 layar alur pembelajaran, repository GenAI + simulasi lokal, dan verifikasi kompilasi APK debug.
