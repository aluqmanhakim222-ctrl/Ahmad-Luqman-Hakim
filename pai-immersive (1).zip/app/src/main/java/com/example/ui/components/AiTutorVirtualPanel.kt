package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.AiToolType
import com.example.model.ClassroomObjectItem
import com.example.ui.AdaptiveQuizUiState
import com.example.ui.AiLabUiState
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorContainerLight
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldDarkText
import com.example.ui.theme.SuccessContainer
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiTutorVirtualPanel(
    selectedObject: ClassroomObjectItem?,
    tutorUiState: AiLabUiState,
    tutorQuizState: AdaptiveQuizUiState,
    onClose: () -> Unit,
    onGenerateCaseStudy: (
        objectName: String,
        paiMaterial: String,
        studentCharacteristics: String,
        classCondition: String,
        localWisdoms: List<String>
    ) -> Unit,
    onAnalyzeStrategy: (
        objectName: String,
        paiMaterial: String,
        studentCharacteristics: String,
        classCondition: String,
        localWisdoms: List<String>
    ) -> Unit,
    onEvaluateStrategyChoice: (
        chosenStrategy: String,
        studentRationale: String,
        objectName: String,
        paiMaterial: String,
        studentCharacteristics: String,
        classCondition: String,
        localWisdoms: List<String>
    ) -> Unit,
    onGenerateQuiz: (paiMaterial: String, localWisdoms: List<String>, objectName: String) -> Unit,
    onAnswerQuiz: (questionIndex: Int, optionIndex: Int) -> Unit,
    onAskTutor: (question: String, objectName: String, paiMaterial: String, localWisdoms: List<String>) -> Unit,
    onRetryTask: () -> Unit
) {
    val activeObjectName = selectedObject?.name ?: "Ruang Kelas Madrasah 3D"
    var paiMaterial by remember(selectedObject?.id) {
        mutableStateOf(
            when (selectedObject?.id) {
                "mushaf" -> "Adab Membaca Al-Qur'an & Tadabbur"
                "kitab_pesantren" -> "Etika Menuntut Ilmu & Tabayyun"
                "panel_batik" -> "Akhlak Mulia & Kearifan Budaya"
                "meja_siswa" -> "Fikih Muamalah & Kerja Sama (Ta'awun)"
                else -> "Strategi Pembelajaran PAI Kontekstual"
            }
        )
    }
    var selectedStudentChar by remember {
        mutableStateOf("Visual, Auditori, Kinestetik & Akademik Beragam")
    }
    var selectedClassCond by remember {
        mutableStateOf("Kelas madrasah heterogen dengan diskusi aktif")
    }
    var selectedWisdoms by remember {
        mutableStateOf(listOf("Tradisi Pesantren", "Gotong Royong"))
    }
    var selectedStrategyChoice by remember {
        mutableStateOf("Problem-Based Learning (PBL)")
    }
    var studentRationale by remember { mutableStateOf("") }
    var tutorQuestion by remember { mutableStateOf("") }
    var showAllQuizKeys by remember { mutableStateOf(false) }

    val materialPresets = listOf(
        "Fikih Muamalah & Zakat",
        "Akhlak Digital & Tabayyun",
        "Praktik Ibadah & Thaharah",
        "Moderasi Beragama",
        "Sejarah Islam Nusantara"
    )
    val studentCharOptions = listOf(
        "Visual, Auditori, Kinestetik & Akademik Beragam",
        "Dominan Kinestetik & Aktif Bergerak",
        "Kesenjangan Kemampuan Membaca Al-Qur'an",
        "Siswa Pasif dalam Diskusi Kelompok"
    )
    val classConditionOptions = listOf(
        "Kelas madrasah heterogen dengan diskusi aktif",
        "Keterbatasan perangkat proyektor di kelas",
        "Lingkungan pondok pesantren berbasis musyawarah",
        "Kelas besar 36 siswa dengan waktu terbatas"
    )
    val localWisdomOptions = listOf(
        "Tradisi Pesantren",
        "Gotong Royong",
        "Batik & Budaya Lokal",
        "Kehidupan Masyarakat Sekitar"
    )
    val strategyOptions = listOf(
        "Problem-Based Learning (PBL)",
        "Project-Based Learning (PjBL)",
        "Cooperative Learning",
        "Contextual Teaching and Learning (CTL)",
        "Demonstrasi"
    )

    Card(
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.5.dp, GoldAccent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vr_ai_tutor_panel")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Emerald-Gold yang menyatu dengan desain ruang kelas VR
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(EmeraldDark, EmeraldPrimary)))
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = GoldContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = GoldDarkText,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI TUTOR PAI (PENDAMPING VR)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldContainer
                        )
                        Text(
                            text = "Objek aktif: $activeObjectName • Gemini AI Dinamis",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.88f)
                        )
                    }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_ai_tutor_vr_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Tutup Panel AI Tutor PAI",
                            tint = GoldContainer
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                // Status integrasi aman tanpa API key frontend
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Terhubung aman via Firebase AI Logic & App Check (tanpa kunci API di frontend).",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 1. Input Materi PAI & Preset
                OutlinedTextField(
                    value = paiMaterial,
                    onValueChange = { paiMaterial = it },
                    label = { Text("Materi PAI yang Dikaji") },
                    placeholder = { Text("Contoh: Fikih Muamalah, Akhlak Digital, Ibadah...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vr_tutor_material_input"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    materialPresets.forEach { preset ->
                        FilterChip(
                            selected = paiMaterial == preset,
                            onClick = { paiMaterial = preset },
                            label = { Text(preset, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 2. Karakteristik Peserta Didik & Kondisi Kelas
                Text(
                    text = "Karakteristik Peserta Didik:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    studentCharOptions.forEach { opt ->
                        FilterChip(
                            selected = selectedStudentChar == opt,
                            onClick = { selectedStudentChar = opt },
                            label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Kondisi Kelas Virtual / Madrasah:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    classConditionOptions.forEach { opt ->
                        FilterChip(
                            selected = selectedClassCond == opt,
                            onClick = { selectedClassCond = opt },
                            label = { Text(opt, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 3. Integrasi Kearifan Lokal Nusantara
                Text(
                    text = "Integrasi Kearifan Lokal:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    localWisdomOptions.forEach { wisdom ->
                        val isSelected = selectedWisdoms.contains(wisdom)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedWisdoms = if (isSelected && selectedWisdoms.size > 1) {
                                    selectedWisdoms - wisdom
                                } else if (!isSelected) {
                                    selectedWisdoms + wisdom
                                } else selectedWisdoms
                            },
                            label = { Text(wisdom, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("vr_wisdom_${wisdom.lowercase().replace(" ", "_").replace("&", "dan")}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tombol Utama Aksi AI Tutor (Studi Kasus, Analisis Strategi, Generate Kuis)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onGenerateCaseStudy(
                                activeObjectName,
                                paiMaterial,
                                selectedStudentChar,
                                selectedClassCond,
                                selectedWisdoms
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("vr_btn_generate_case_study")
                    ) {
                        Icon(Icons.Filled.School, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GENERATE STUDI KASUS",
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            textAlign = TextAlign.Center
                        )
                    }
                    Button(
                        onClick = {
                            onAnalyzeStrategy(
                                activeObjectName,
                                paiMaterial,
                                selectedStudentChar,
                                selectedClassCond,
                                selectedWisdoms
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("vr_btn_analyze_strategy")
                    ) {
                        Icon(Icons.Filled.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ANALISIS STRATEGI",
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { onGenerateQuiz(paiMaterial, selectedWisdoms, activeObjectName) },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 50.dp)
                        .testTag("vr_btn_generate_quiz")
                ) {
                    Icon(Icons.Filled.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE KUIS (5 SOAL + KUNCI & PEMBAHASAN)",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // 4. Pilihan Strategi Mahasiswa & Umpan Balik Pedagogis
                Text(
                    text = "Umpan Balik Pilihan Strategi Mahasiswa:",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    strategyOptions.forEach { strat ->
                        FilterChip(
                            selected = selectedStrategyChoice == strat,
                            onClick = { selectedStrategyChoice = strat },
                            label = { Text(strat, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.testTag("vr_strat_chip_${strat.take(6).trim()}")
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = studentRationale,
                    onValueChange = { studentRationale = it },
                    label = { Text("Alasan / Rancangan Singkat Pilihan Anda") },
                    placeholder = { Text("Contoh: Saya memilih PBL dengan gotong royong agar siswa aktif memecahkan masalah...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vr_student_rationale_input"),
                    minLines = 2,
                    maxLines = 3
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        onEvaluateStrategyChoice(
                            selectedStrategyChoice,
                            studentRationale,
                            activeObjectName,
                            paiMaterial,
                            selectedStudentChar,
                            selectedClassCond,
                            selectedWisdoms
                        )
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("vr_btn_strategy_feedback")
                ) {
                    Icon(Icons.Filled.Psychology, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "UMPAN BALIK PILIHAN STRATEGI",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // 5. Tanya AI Tutor
                Text(
                    text = "Tanya AI Tutor PAI:",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = tutorQuestion,
                    onValueChange = { tutorQuestion = it },
                    label = { Text("Ajukan pertanyaan tentang Strategi Pembelajaran PAI") },
                    placeholder = { Text("Contoh: Bagaimana memadukan batik lokal dengan CTL di kelas XI?") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vr_tutor_question_input"),
                    minLines = 2,
                    maxLines = 3
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        onAskTutor(tutorQuestion, activeObjectName, paiMaterial, selectedWisdoms)
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("vr_btn_ask_ai_tutor")
                ) {
                    Icon(Icons.Filled.Forum, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TANYA AI TUTOR",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Output Area (Streaming / Hasil Studi Kasus / Analisis / Umpan Balik / Tanya Tutor)
                Spacer(modifier = Modifier.height(12.dp))
                VrTutorOutputSection(
                    tutorUiState = tutorUiState,
                    onRetryTask = onRetryTask
                )

                // Quiz Output Area (5 Soal lengkap dengan Kunci Jawaban & Pembahasan)
                Spacer(modifier = Modifier.height(10.dp))
                VrTutorQuizSection(
                    tutorQuizState = tutorQuizState,
                    showAllKeys = showAllQuizKeys,
                    onToggleAllKeys = { showAllQuizKeys = !showAllQuizKeys },
                    onAnswerQuiz = onAnswerQuiz,
                    onRetryQuiz = { onGenerateQuiz(paiMaterial, selectedWisdoms, activeObjectName) }
                )
            }
        }
    }
}

@Composable
private fun VrTutorOutputSection(
    tutorUiState: AiLabUiState,
    onRetryTask: () -> Unit
) {
    when (tutorUiState) {
        AiLabUiState.Idle -> {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Pilih salah satu aksi di atas (Generate Studi Kasus, Analisis Strategi, Umpan Balik, Generate Kuis, atau Tanya AI Tutor) untuk berinteraksi dengan pendamping Gemini AI di ruang kelas VR.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
        is AiLabUiState.Loading -> {
            Card(
                colors = CardDefaults.cardColors(containerColor = GoldContainer.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "AI Tutor PAI sedang menyusun respons dinamis dari Gemini AI...",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        is AiLabUiState.Streaming -> {
            VrTutorResultCard(
                title = "AI Tutor PAI Menulis Secara Real-Time...",
                body = tutorUiState.text,
                badgeLabel = tutorUiState.sourceMode.label
            )
        }
        is AiLabUiState.Success -> {
            val heading = when (tutorUiState.toolType) {
                AiToolType.CASE_STUDY -> "Studi Kasus PAI Baru (VR)"
                AiToolType.STRATEGY_ANALYSIS -> "Analisis & Umpan Balik Strategi PAI"
                AiToolType.AI_TUTOR -> "Jawaban AI Tutor PAI"
                AiToolType.QUIZ -> "Kuis Strategi PAI"
            }
            VrTutorResultCard(
                title = "$heading • ${tutorUiState.difficulty.label}",
                body = tutorUiState.text,
                badgeLabel = tutorUiState.sourceMode.label
            )
        }
        is AiLabUiState.Error -> {
            Card(
                colors = CardDefaults.cardColors(containerColor = ErrorContainerLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vr_tutor_error_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = ErrorCrimson)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Koneksi Gemini AI Terkendala",
                            style = MaterialTheme.typography.titleSmall,
                            color = ErrorCrimson
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(tutorUiState.message, style = MaterialTheme.typography.bodySmall, color = ErrorCrimson)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onRetryTask,
                        modifier = Modifier.testTag("vr_btn_retry_ai")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Coba Lagi")
                    }
                }
            }
        }
    }
}

@Composable
private fun VrTutorResultCard(
    title: String,
    body: String,
    badgeLabel: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vr_tutor_output_card")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(color = GoldContainer, shape = MaterialTheme.shapes.small) {
                    Text(
                        text = badgeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldDarkText,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun VrTutorQuizSection(
    tutorQuizState: AdaptiveQuizUiState,
    showAllKeys: Boolean,
    onToggleAllKeys: () -> Unit,
    onAnswerQuiz: (Int, Int) -> Unit,
    onRetryQuiz: () -> Unit
) {
    when (tutorQuizState) {
        AdaptiveQuizUiState.Idle -> Unit
        AdaptiveQuizUiState.Loading -> {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Menyusun 5 soal kuis Strategi Pembelajaran PAI dari Gemini AI...", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        is AdaptiveQuizUiState.Error -> {
            Card(
                colors = CardDefaults.cardColors(containerColor = ErrorContainerLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(tutorQuizState.message, style = MaterialTheme.typography.bodySmall, color = ErrorCrimson)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = onRetryQuiz) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Buat Ulang 5 Soal Kuis")
                    }
                }
            }
        }
        is AdaptiveQuizUiState.Ready -> {
            val total = tutorQuizState.questions.size
            val answered = tutorQuizState.selectedAnswers.size
            val correctCount = tutorQuizState.questions.indices.count { idx ->
                tutorQuizState.selectedAnswers[idx] == tutorQuizState.questions[idx].correctIndex
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vr_quiz_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kuis AI Tutor PAI ($total Soal)",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Surface(color = GoldContainer, shape = MaterialTheme.shapes.small) {
                            Text(
                                text = "Terjawab $answered/$total",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldDarkText,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    TextButton(
                        onClick = onToggleAllKeys,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("vr_btn_toggle_quiz_keys")
                    ) {
                        Icon(
                            imageVector = if (showAllKeys) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (showAllKeys) "Sembunyikan Kunci & Pembahasan" else "Lihat Kunci Jawaban & Pembahasan",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    tutorQuizState.questions.forEachIndexed { qIdx, q ->
                        val pickedIdx = tutorQuizState.selectedAnswers[qIdx]
                        val revealDetail = pickedIdx != null || showAllKeys
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Soal ${qIdx + 1} • ${q.topic}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldDarkText
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = q.question,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                q.options.forEachIndexed { optIdx, optText ->
                                    val isPicked = pickedIdx == optIdx
                                    val isCorrect = optIdx == q.correctIndex
                                    val bg = when {
                                        revealDetail && isCorrect -> SuccessContainer
                                        isPicked && !isCorrect -> ErrorContainerLight
                                        else -> MaterialTheme.colorScheme.surface
                                    }
                                    Card(
                                        onClick = { onAnswerQuiz(qIdx, optIdx) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp)
                                            .testTag("vr_quiz_${qIdx}_opt_${optIdx}"),
                                        colors = CardDefaults.cardColors(containerColor = bg)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(9.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${'A' + optIdx}. $optText",
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.weight(1f)
                                            )
                                            if (revealDetail && isCorrect) {
                                                Icon(
                                                    imageVector = Icons.Filled.CheckCircle,
                                                    contentDescription = "Kunci Jawaban",
                                                    tint = SuccessGreen,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                if (revealDetail) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val keyLetter = 'A' + q.correctIndex.coerceIn(0, 3)
                                    Text(
                                        text = "Kunci Jawaban: $keyLetter • Pembahasan: ${q.explanation}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    if (answered == total && total > 0) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = SuccessContainer,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Skor Kuis VR Anda: $correctCount/$total benar (${(correctCount * 100) / total}%).",
                                style = MaterialTheme.typography.bodySmall,
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
